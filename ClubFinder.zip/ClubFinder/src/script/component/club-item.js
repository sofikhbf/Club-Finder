class ClubItem extends HTMLElement {

    constructor() {
      super();
      this.shadowDOM = this.attachShadow({mode: 'open'});
    }
  
    set club(club) {
      this._club = club;
      this.render();
    }
  
    render() {
      this.shadowDOM.innerHTML = `
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          :host {
            display: block;
            margin-bottom: 18px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            overflow: hidden;
          }
          .fan-art-club {
            width: 100%;
            max-height: 300px;
            object-fit: cover;
            object-position: center;
          }
          .club-info {
            padding: 24px;
          }
          .club-info > h2 {
            font-weight: lighter;
          }
          .club-info > p {
            margin-top: 10px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 10; /* number of lines to show */
          }
        </style>
        <img class="fan-art-club" src="${this._club.strTeamBadge}" alt="Fan Art">
        <div class="club-info">
          <h2>${this._club.strTeam}</h2>
          <h3>${this._club.strAlternate}</h3>
          <h4>${this._club.intFormedYear}</h4>
          <h5>${this._club.strSport}</h5>
          <h6>${this._club.strLeague}</h6>
          <h7>${this._club.strLeague2}</h7>
          <h8>${this._club.strLeague3}</h8>
          <h9>${this._club.strStadium}</h9>
          <h10>${this._club.strKeywoards}</h10>
          <p>${this._club.strDescriptionEN}</p>
        </div>
      `;
    }
  }
  
  customElements.define('club-item', ClubItem);